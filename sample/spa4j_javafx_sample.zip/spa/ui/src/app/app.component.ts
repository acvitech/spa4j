import { Component, NgModule } from '@angular/core';
declare let controller:any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})


export class AppComponent {
  title = 'Angular-SPA4J Sample';
  filename = "";
  directory = "";
  newFilename = "";
  filecontent = "";

  private openJFXDialog(){
    this.filename = controller.showOpenDialog();
    console.log("Opening File from: "+this.filecontent);
    this.filecontent = controller.readFileAsString(this.filename);
  }

  private openJFXDirDialog(){
    this.directory = controller.showDirectoryDialog();
  }

  private openJFXCreateFileDialog(){
    console.log("Saving File to: "+this.filecontent);
    this.newFilename = controller.createFile(this.filecontent);
  }
}
