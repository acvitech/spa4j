/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

module com.ec.eca.cme {
    requires com.acvitech.spa4j;
    requires jdk.jsobject;
    requires java.desktop;
}
