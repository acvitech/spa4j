
module com.acvitech.desktopapp {
    requires com.acvitech.spa4j;
    requires jdk.jsobject;
    requires java.desktop;
}
