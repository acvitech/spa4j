/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.acvitech.starter;

import com.acvitech.beans.Controller;
import com.acvitech.spa4j.jfx.JFXApplication;



/**
 *
 * @author avikarz
 */
public class Starter {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]){        
        JFXApplication.prepare()
                .addBean("controller", Controller.class)
                .setIcon("/ui/assets/img/spa4j.png")
                .setTitle("SPA4J Sample App")
                .setStartUrl("/ui/index.html")
                .launch(args);
    }
    
    
}
