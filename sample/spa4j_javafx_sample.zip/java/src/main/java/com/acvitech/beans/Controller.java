
package com.acvitech.beans;

import com.acvitech.spa4j.util.Bean;
import com.acvitech.spa4j.util.RuntimeSettings;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;

/**
 *
 * @author avikarz
 */
public class Controller implements Bean{

    @Override
    public void init() {
        System.out.println("Bean Initialised");
    }

    @Override
    public void destroy() {
        System.out.println("Bean is about to be destroyed");
    }
    
    public String showOpenDialog(){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open a Text file");
        FileChooser.ExtensionFilter extensionFilter = new FileChooser.ExtensionFilter("Text (*.txt)", "*.txt");
        fileChooser.getExtensionFilters().add(extensionFilter);
        File file = fileChooser.showOpenDialog(RuntimeSettings.getStage());
        return file.getAbsolutePath();
    }
    
    public String createFile(String info){
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Create a Settings file for Update");
        fileChooser.setInitialFileName("testfile.txt");
        fileChooser.getExtensionFilters().addAll(new FileChooser.ExtensionFilter("Sample File", "*.txt"),
        new FileChooser.ExtensionFilter("All Files", "*.*"));
        File file = fileChooser.showSaveDialog(RuntimeSettings.getStage());
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException ex) {
                //Replace the following with approprite logging statement
                ex.printStackTrace();
            }
        }
        try (FileWriter fileWriter = new FileWriter(file)) {
            fileWriter.write(info);
        } catch (IOException ex) {
            //Replace the following with approprite logging statement
            ex.printStackTrace();
        }
        return file.getAbsolutePath();
    }
   
    public String readFileAsString(String filePath)
    {
        String content = "";
        try{
            content = new String ( Files.readAllBytes( Paths.get(filePath) ) );
        }catch (IOException e){
            //Replace the following with approprite logging statement
            e.printStackTrace();
        }
        return content;
    }
    
    public String showDirectoryDialog(){
        DirectoryChooser directoryChooser = new DirectoryChooser();
        File selectedDirectory = directoryChooser.showDialog(RuntimeSettings.getStage());
        return selectedDirectory.getAbsolutePath();
    }
    
}
